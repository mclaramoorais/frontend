
const express = require('express')
const path = require('path')

const app = express()

const PORT = 3000

app.get('/', (req, res) =>{
    res.sendFile(path.join(__dirname, "public", "index.html"))
})

//Rota para a página da pizza de calabresa '/pizza/calabresa'
app.get('/pizza/calabresa', (req, res) =>{
    res.sendFile(path.join(__dirname, 'public', 'calabresa.html'))
})

//Rota para a página da pizza de mussarela '/pizza/mussarela'
app.get('/pizza/mussarela', (req, res) =>{
    res.sendFile(path.join(__dirname, "public", "mussarela.html"))
})

app.listen(PORT, () =>{
    console.log('Servidor rodando com sucesso!')
})

