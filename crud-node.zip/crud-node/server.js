const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// CREATE
app.post("/users", (req, res) => {
const { name, email } = req.body;
db.query(
"INSERT INTO users (name, email) VALUES (?, ?)",
[name, email],
(err, result) => {
if (err) throw err;
res.json({ message: "Usuário criado!", id: result.insertId });
}
);
});

// READ
app.get("/users", (req, res) => {
db.query("SELECT * FROM users", (err, result) => {
if (err) throw err;
res.json(result);
});
});

// UPDATE
app.put("/users/:id", (req, res) => {
const { id } = req.params;
const { name, email } = req.body;
db.query(
"UPDATE users SET name = ?, email = ? WHERE id = ?",
[name, email, id],
(err) => {
if (err) throw err;
res.json({ message: "Usuário atualizado!" });
}
);
});

// DELETE
app.delete("/users/:id", (req, res) => {
const { id } = req.params;
db.query("DELETE FROM users WHERE id = ?", [id], (err) => {
if (err) throw err;
res.json({ message: "Usuário excluído!" });
});
});

// Iniciar servidor
app.listen(3000, () => {
console.log("Servidor rodando em http://localhost:3000");
});